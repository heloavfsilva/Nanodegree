# Ford GoBike System Data Exploration
## by Heloa Silva


## Dataset

This document explores a dataset about individual rides made in a bike-sharing system
covering the greater San Francisco for the first semester of 2018 and first semester of 2019.

## Summary of Findings

In the end, find the difference of the 2018 first semester with 2019 same period.
when I picked this dataset I was wondering the growth were exponential and massive,
but the data it's showing that more rides were taken back in 2018 compared to this year.

## Key Insights for Presentation

Drill down the user type information to understand the relation between this variable
along the time and how it may impact the way the company are interacting with them.